Plugin Builder Results

Your plugin ByPasHaz was created in:
    C:/Users/antoi/Documents/Savoir/Geographie/Projet/Atelier_M2/Taitement/RES/PLUGIN\bypass_hazards

Your QGIS plugin directory is located at:
    C:/Users/antoi/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins

What's Next:

  * Copy the entire directory containing your new plugin to the QGIS plugin
    directory

  * Run the tests (``make test``)

  * Test the plugin by enabling it in the QGIS plugin manager

  * Customize it by editing the implementation file: ``bypass_hazards.py``

  * You can use the Makefile to compile your Ui and resource files when
    you make changes. This requires GNU make (gmake)

For more information, see the PyQGIS Developer Cookbook at:
http://www.qgis.org/pyqgis-cookbook/index.html

(C) 2011-2018 GeoApt LLC - geoapt.com
